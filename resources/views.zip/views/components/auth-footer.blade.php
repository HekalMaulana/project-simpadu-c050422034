  <div class="simple-footer">
      Copyright &copy; simpadu-c030322999 2023
  </div>
